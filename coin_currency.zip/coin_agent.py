import tensorflow as tf
import numpy as np
import random
#import time
#import datetime

from dqn import coin_dqn
from trade_board import setting
import train_test_data

tf.app.flags.DEFINE_boolean('train', True, 'on learning mode.')
FLAGS = tf.app.flags.FLAGS

MAX_EPISODE = 10000
TARGET_UPDATE_INTERVAL = 1000
TRAIN_INTERVAL = 5
OBSERVE = 1000      # must larger than batch_size (every batch should be chosen in observed state)

# action: 0(cell max), 3(buy max) by remainder of divided by 8
#           quotient of divided by 8 means kind of coin
act_species = setting.act_species
NUM_ACTION = act_species * len(setting.currency)
LENGTH = len(setting.parameters)
TIMELINE = setting.timeline       # same as in setting.py
CURRENCY = len(setting.currency)
CHART = len(setting.candle_state)


def train():
    sess = tf.Session()

    setting.load_data(setting.currency, train_test_data.file_list, train_test_data.test_file)
    brain = coin_dqn.DQN(sess, CURRENCY, CHART, TIMELINE, LENGTH, NUM_ACTION)

    rewards = tf.placeholder(tf.float32, [None])
    tf.summary.scalar('avg.reward/ep.', tf.reduce_mean(rewards))

    saver = tf.train.Saver(tf.global_variables())
    ckpt = tf.train.get_checkpoint_state('./coin_model')

    if ckpt and tf.train.checkpoint_exists(ckpt.model_checkpoint_path):
        print('model has been loaded successfully!')
        saver.restore(sess, ckpt.model_checkpoint_path)
    else:
        print('start new progress.')
        sess.run(tf.global_variables_initializer())

    writer = tf.summary.FileWriter('coin_logs', sess.graph)
    summary_merged = tf.summary.merge_all()

    brain.update_target_network()       # initialize target network

    epsilon = 1.0       # parameter defining ratio between random action and DQN decision
    time_step = 0       # frame number
    total_reward_list = []

    for episode in range(MAX_EPISODE):
        terminal = False
        total_reward = 0

        # initialize game with screen (screen_width, screen_height)
        state = setting.reset()
        brain.init_state(state)

        while not terminal:
            if np.random.rand() < epsilon:          # choosing random action in early phase (little learning data)
                action = random.randrange(NUM_ACTION)
            else:
                action = brain.get_action()         # choosing DQN decision

            if episode > OBSERVE:                   # decreasing epsilon to increase DQN decision's ratio
                epsilon -= 1 / 500000

            state, reward, terminal, _ = setting.step(action)
            total_reward += reward

            brain.state_remember(state, action, reward, terminal)

            if time_step > 3000 and time_step % TRAIN_INTERVAL == 0:
                brain.train()   # in this step, memory length(=time step) must be longer than batch size

            if time_step % TARGET_UPDATE_INTERVAL == 0:
                brain.update_target_network()

            time_step += 1

        print('episode #: %d   reward: %d   epsilon: %f' % (episode + 1, total_reward, epsilon))

        total_reward_list.append(total_reward)

        if episode % 1000 == 0 and episode != 0:
            summary = sess.run(summary_merged, feed_dict={rewards: total_reward_list})
            writer.add_summary(summary, time_step)
            total_reward_list = []

        if episode % 500 == 0 and episode != 0:
            saver.save(sess, 'coin_model/coin_dqn.ckpt', global_step=time_step)


def replay():
    sess = tf.Session()

    setting.load_data(setting.currency, train_test_data.file_list, train_test_data.test_file)
    brain = coin_dqn.DQN(sess, CURRENCY, TIMELINE, LENGTH, NUM_ACTION)

    saver = tf.train.Saver()
    ckpt = tf.train.get_checkpoint_state('./coin_model')
    saver.restore(sess, ckpt.model_checkpoint_path)
    print('model has been loaded for test mode.')

    for episode in range(MAX_EPISODE):
        terminal = False
        total_reward = 0

        state = setting.reset()
        brain.init_state(state)

        while not terminal:
            action = brain.get_action()

            state, reward, terminal, _ = setting.step(action)
            total_reward += reward

            brain.state_remember(state, action, reward, terminal)

        print('episode #: %d score: %d' % (episode + 1, total_reward))


def main(_):
    if FLAGS.train:
        train()
    else:
        replay()


if __name__ == '__main__':
    tf.app.run()
